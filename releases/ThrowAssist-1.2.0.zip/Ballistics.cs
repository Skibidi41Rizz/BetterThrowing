using System;

namespace ThrowAssist
{
    /// <summary>
    /// Чистая математика броска, без UnityEngine: можно проверять обычным консольным тестом.
    /// Гравитация постоянная, сопротивление воздуха учитывается коэффициентом drag (1/с).
    /// </summary>
    public static class Ballistics
    {
        /// <summary>
        /// Подбирает скорость, при которой тело из точки броска попадёт в цель.
        /// Возвращает false, если нужная скорость больше maxSpeed (цель слишком далеко/высоко).
        /// </summary>
        public static bool Solve(float flatDist, float heightDiff, float naturalHorizontalSpeed,
                                 float gravity, float drag, float maxFlightTime, float maxSpeed,
                                 out float horizontalSpeed, out float verticalSpeed, out float flightTime)
        {
            horizontalSpeed = 0f;
            verticalSpeed = 0f;
            flightTime = 0f;

            if (flatDist < 0.05f || naturalHorizontalSpeed <= 0.01f || gravity <= 0f)
                return false;

            // Держим горизонтальную скорость игрока, но не даём броску лететь слишком долго.
            float t = flatDist / naturalHorizontalSpeed;
            if (t < 0.1f) t = 0.1f;
            if (t > maxFlightTime) t = maxFlightTime;

            flightTime = t;
            if (drag < 0.001f)
            {
                horizontalSpeed = flatDist / t;
                verticalSpeed = heightDiff / t + 0.5f * gravity * t;
            }
            else
            {
                // v' = -drag*v (+ гравитация). x(t) = (v/drag)(1-e^-drag*t).
                double e = Math.Exp(-drag * t);
                double oneMinusE = 1.0 - e;
                if (oneMinusE < 1e-4) return false;

                double k = drag;
                horizontalSpeed = (float)(flatDist * k / oneMinusE);
                verticalSpeed = (float)((k * heightDiff + gravity * t) / oneMinusE - gravity / k);
            }

            float speed = (float)Math.Sqrt(horizontalSpeed * horizontalSpeed + verticalSpeed * verticalSpeed);
            return speed <= maxSpeed;
        }
    }
}
